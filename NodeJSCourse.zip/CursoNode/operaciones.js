function suma(x, y){
    return x+y;
}

function resta(x, y){
    return x-y;
}



exports.suma = suma;
exports.resta = resta;
