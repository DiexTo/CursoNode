const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    try{
        console.log(req.params.token);
        const token = req.params.token;
        const verify = jwt.verify(token, 'cursonode');
        req.userdata = verify;
        next();
    }
    catch(error){
        return res.status(401).json({
            message: 'token invalid'
        })
    }
    
}