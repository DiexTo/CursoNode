
const persona = {
    nombre : 'Jose Lopez',
    edad : 20,
    sexo : 'M'
};


const animal = {
    
};

module.exports = persona;