const mongoose = require('mongoose');
const express = require('express');
const modelo = require('../model/user');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const routes = express.Router();

const Users = mongoose.model('Users', modelo);
const usuarios = {};

var user;

routes.post('/', async (req, res) => {
    // Buscar si el correo/usuario existe; Sino existe crearlo; si existe, mandar mensaje de usuario existente.
    let user = Users.find({
        telefono: req.body.telefono
    }).exec()
    .then(user => {
        if(user.length > 0){
            return res.status(400).json({
                message: 'Telefono existente'
            });
        }
        else{
            bcrypt.hash(req.body.password, 10, (err, hash) =>{
                if(err){
                    return res.status(500).json({
                        error: err
                    });
                }
                else
                {
                    user = new Users({
                        _id: new mongoose.Types.ObjectId(),
                        correo: req.body.correo,
                        password: hash,
                        telefono: req.body.telefono
                    });
                    user.save()
                    .then(data =>{
                        console.log(data);
                        res.status(201).json({
                            message: "Usuario Registrado",
                        });
                    })
                    .catch(err =>{
                        res.status(409).json({
                            message: err.message
                            });
                        })
                }
            });
        }
    })
    .catch(err => {
        json.status(400).json({
            error: err
        })
    })
});

routes.post('/login', (req, res) => {
    Users.find({correo: req.body.correo})
    .exec()
    .then(Values => {
        if(Values.length <= 0){
            return res.status(401).json({
                message: "Autentificacion Fallida correo invalido"
            });
        }else
        {
            bcrypt.compare(req.body.password, Values[0].password, (err, resul) => {
                if(err){
                    return res.status(401).json({
                        message: "Autentificacion Fallida password invalido"
                    });
                }
                if(resul){
                    const token = jwt.sign(
                        {
                            correo: Values[0].correo,
                            telefono: Values[0].telefono
                        },
                        'cursonode',
                        {
                            expiresIn: '1h'
                        }
                    );
                    return res.status(201).json({
                        message: token
                    });
                }
                else
                {
                    return res.status(401).json({
                        message: err
                    });
                }
            });
        }
    })
    .catch(err => {
        res.status(500).json({
            message: err
        });
    })
});



module.exports = routes;