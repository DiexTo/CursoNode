const mongoose = require('mongoose');
const modelo = require('../model/product');
const multer = require('multer');

const Products = mongoose.model('Product', modelo);
const products = {};


products.addProduct = async (req,res) =>{
    
    let productoagregdo = new Products(req.body);
    productoagregdo.save()
    .then(data =>{
        console.log(data);
        res.status(201).json({
            message: "Producto Agregado",
        })
//        res.json(data);
    })
    .catch(err =>{
        res.status(409).json({
            message: err.message
        })
    })
};

products.getProduct = async (req, res )=>{
    const listaproductos = await Products.find()
    .select("name price cantidad")
    .exec()
    .then(data =>{
        res.status(202).json(data);
    })
    .catch(err =>{
        res.status(404).json({
            message: "Lista de productos vacios"
        })
    })
    //res.json(listaproductos);
}

products.getProductid = async (req, res) =>{
    const productid = req.params.id;
    Products.findById(productid)
    .exec()
    .then(values =>{
        res.status(202).json(values)
    })
    .catch(err =>{
        res.status(404).json({
            message: "Producto No existe"
        })
    })
    // const id = req.params.id;
    // //console.log(id);
    // res.json(id);
}

products.delProduct = async(req, res) =>{
    const productid = req.params.productid;
    Products.deleteOne({_id : productid})
    .exec()
    .then(data =>{
        res.status(202).json({
            message: "Producto Eliminado"
        });
    })
    .catch(err =>{
        res.status(404).json({
            message: "Lista de productos vacios"
        })
    });
}

products.patch = async (req, res) =>{
    const id = req.params.productid;
    // const valuesup = {};
    // for(const i of req.body){
    //     console.log(req.body);
    //     valuesup[i.propName] = i.value;
    // }
    // console.log(this.valuesup);
    Products.update({ _id:id }, { $set: {
        name: req.body.newname,
        price: req.body.newprice
    }})
    .exec()
    .then(values => {
        res.status(200).json({
            message: values
        })
    })
    .catch(err => {
        res.status(404).json({
            message: err
        })
    })
}





module.exports = products;